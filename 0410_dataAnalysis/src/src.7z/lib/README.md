# Interfaz de Creacion y Visualización

Para que funcione pyqt6 fue necesario instalar algunos plugings en como:
"""
sudo apt-get update
sudo apt-get install libxcb-cursor0
sudo apt-get install libxcb-xinerama0
"""

- quitarle la parte de grafica contra index